
public class functions {
public void sayHello() {
	System.out.println("Hello world;");
}
}
